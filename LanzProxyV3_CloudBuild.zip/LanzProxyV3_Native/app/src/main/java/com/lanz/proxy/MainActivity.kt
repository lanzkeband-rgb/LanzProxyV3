package com.lanz.proxy

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color

class MainActivity : Activity() {
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(24), dp(24), dp(24), dp(24))
            setBackgroundColor(Color.rgb(8, 13, 24))
        }
        root.addView(TextView(this).apply {
            text = "LANZ PROXY V3"
            textSize = 27f; gravity = Gravity.CENTER
            setTextColor(Color.rgb(70, 180, 255))
        })
        root.addView(TextView(this).apply {
            text = "NATIVE FLOATING COMPANION"
            textSize = 12f; gravity = Gravity.CENTER
            setTextColor(Color.LTGRAY); setPadding(0, dp(10), 0, dp(22))
        })
        root.addView(Button(this).apply {
            text = "AKTIFKAN FLOATING MENU"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")))
                } else {
                    val i = Intent(this@MainActivity, OverlayService::class.java)
                    if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
                    text = "FLOATING MENU DIMINTA AKTIF"
                }
            }
        })
        root.addView(Button(this).apply {
            text = "MATIKAN FLOATING MENU"
            setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
        root.addView(TextView(this).apply {
            text = "\nCara pakai:\n1. Izinkan tampil di atas aplikasi lain.\n2. Aktifkan floating menu.\n3. Kembali ke game; tekan gelembung L untuk membuka panel.\n\nCrosshair hanya penanda visual. Tidak ada aimbot, ESP, atau pembaca posisi musuh."
            textSize = 13f; setTextColor(Color.LTGRAY); setPadding(0, dp(18), 0, 0)
        })
        setContentView(root)
    }
}
