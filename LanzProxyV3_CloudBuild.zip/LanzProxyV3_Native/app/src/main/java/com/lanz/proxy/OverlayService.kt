package com.lanz.proxy

import android.app.*
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.*
import android.widget.*
import android.graphics.drawable.GradientDrawable

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var cross: TextView? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private var crossEnabled = true
    private var panelVisible = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun bg(color: Int, radius: Float, stroke: Int = Color.TRANSPARENT) =
        GradientDrawable().apply { setColor(color); cornerRadius = dp(radius.toInt()).toFloat(); if (stroke != Color.TRANSPARENT) setStroke(dp(1), stroke) }

    override fun onCreate() {
        super.onCreate()
        createNotification()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        addBubble()
        addCrosshair()
    }

    private fun createNotification() {
        val channel = "lanz_overlay"
        if (Build.VERSION.SDK_INT >= 26) {
            val c = NotificationChannel(channel, "LANZ PROXY overlay", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(c)
        }
        val n = Notification.Builder(this, channel)
            .setContentTitle("LANZ PROXY aktif")
            .setContentText("Floating companion berjalan. Ketuk gelembung L untuk membuka menu.")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true).build()
        startForeground(31, n)
    }

    private fun overlayParams(w: Int, h: Int, gravity: Int = Gravity.TOP or Gravity.START): WindowManager.LayoutParams {
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE
        return WindowManager.LayoutParams(w, h, type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { this.gravity = gravity }
    }

    private fun addBubble() {
        bubble = TextView(this).apply {
            text = "L"; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            background = bg(Color.rgb(13, 123, 204), 28f, Color.rgb(100, 195, 255))
            elevation = dp(8).toFloat()
            setOnClickListener { togglePanel() }
            setOnTouchListener(object : View.OnTouchListener {
                var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
                override fun onTouch(v: View, e: MotionEvent): Boolean {
                    val p = v.layoutParams as WindowManager.LayoutParams
                    when (e.action) {
                        MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=p.x; oy=p.y; moved=false; return true }
                        MotionEvent.ACTION_MOVE -> { val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt(); if (kotlin.math.abs(dx)+kotlin.math.abs(dy)>dp(5)) moved=true; p.x=ox+dx; p.y=oy+dy; wm.updateViewLayout(v,p); return true }
                        MotionEvent.ACTION_UP -> { if (!moved) performClick(); return true }
                    }
                    return false
                }
            })
        }
        wm.addView(bubble, overlayParams(dp(52), dp(52)).apply { x=dp(8); y=dp(180) })
    }

    private fun addCrosshair() {
        cross = TextView(this).apply {
            text = "+"; textSize = 32f; gravity = Gravity.CENTER
            setTextColor(Color.GREEN); setShadowLayer(dp(5).toFloat(), 0f, 0f, Color.GREEN)
        }
        val p = overlayParams(dp(60), dp(60), Gravity.CENTER).apply {
            flags = flags or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
        }
        wm.addView(cross, p)
    }

    private fun togglePanel() {
        if (panelVisible) { removePanel(); return }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(dp(14), dp(12), dp(14), dp(12))
            background = bg(Color.argb(245, 10, 20, 36), 18f, Color.rgb(48, 125, 185))
            elevation = dp(12).toFloat()
        }
        box.addView(TextView(this).apply {
            text = "LANZ PROXY V3"; textSize = 19f; setTextColor(Color.rgb(85,190,255))
        })
        box.addView(TextView(this).apply {
            text = "FLOATING GAMING COMPANION"; textSize = 10f; setTextColor(Color.LTGRAY)
            setPadding(0, 0, 0, dp(8))
        })
        val toggle = Switch(this).apply {
            text = "CROSSHAIR OVERLAY"; setTextColor(Color.WHITE); isChecked = crossEnabled
            setOnCheckedChangeListener { _, checked -> crossEnabled=checked; cross?.visibility=if(checked) View.VISIBLE else View.GONE }
        }
        box.addView(toggle)
        box.addView(TextView(this).apply {
            text = "Radar: simulasi saja • FPS/ping game tidak dapat dibaca dari overlay ini."
            textSize = 11f; setTextColor(Color.LTGRAY); setPadding(0, dp(8), 0, dp(8))
        })
        box.addView(Button(this).apply { text="MINIMALKAN"; setOnClickListener { removePanel() } })
        box.addView(Button(this).apply { text="MATIKAN LAYANAN"; setOnClickListener { stopSelf() } })
        panel = box
        panelParams = overlayParams(dp(270), WindowManager.LayoutParams.WRAP_CONTENT).apply { x=dp(14); y=dp(100) }
        wm.addView(box, panelParams)
        panelVisible = true
    }

    private fun removePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; panelVisible = false
    }

    override fun onDestroy() {
        removePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        cross?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble=null; cross=null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}
