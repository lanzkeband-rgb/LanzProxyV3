plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.lanz.proxy"
    compileSdk = 36
    defaultConfig {
        applicationId = "com.lanz.proxy"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "3.0"
    }
}
