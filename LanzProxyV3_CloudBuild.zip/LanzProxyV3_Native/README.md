# LANZ PROXY V3 — Native Android overlay starter

Project Kotlin native untuk Android. Menyediakan gelembung mengambang yang bisa digeser, panel LANZ, dan crosshair visual di atas aplikasi lain.

## Build APK
1. Buka folder project ini dengan Android Studio versi baru.
2. Pasang Android SDK Platform 36 dan JDK 17.
3. Tunggu Gradle Sync.
4. Pilih Build > Build APK(s).
5. APK debug: `app/build/outputs/apk/debug/app-debug.apk`.

## Cara uji di HP
1. Install APK debug.
2. Buka LANZ PROXY, tekan Aktifkan Floating Menu.
3. Izinkan "Display over other apps".
4. Kembali ke aplikasi dan tekan gelembung L.
5. Uji dulu di layar utama, lalu cek apakah perangkat mengizinkan overlay saat game berjalan.

## Batasan penting
- Overlay Android dapat dibatasi oleh game, mode layar penuh, pengaturan sistem, atau kebijakan anti-cheat. Tidak ada jaminan selalu tampil di Free Fire.
- Crosshair hanya tanda visual, bukan aimbot.
- Tidak ada ESP/wallhack atau pelacakan posisi musuh.
- FPS internal Free Fire dan ping server game tidak dapat dibaca secara andal oleh companion app biasa; metrik browser/perangkat bukan metrik game.
- Untuk distribusi publik, tinjau kebijakan Google Play dan aturan game.
